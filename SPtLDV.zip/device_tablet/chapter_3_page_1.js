TabletResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff","bgImage":"images/background.png","bgSize":"1009px 630px","bgRepeat":"repeat-y"}
,
"image4429":{"x":0,"y":0,"w":1009,"h":86,"bOffBottom":0,"i":"images/header.png"}
,
"image4431":{"x":0,"y":572,"w":1009,"h":90,"bOffBottom":1,"i":"images/footer.png"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/background.png']
},
"785":{
"pageLayer":{"w":785,"h":1000,"bgColor":"#999999","bgImage":"images/background001.png","bgSize":"785px 569px","bgRepeat":"repeat-y"}
,
"image4429":{"x":0,"y":0,"w":785,"h":86,"bOffBottom":0,"i":"images/header001.png"}
,
"image4431":{"x":0,"y":924,"w":785,"h":76,"bOffBottom":1,"i":"images/footer001.png"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/header001.png','images/footer001.png','images/background001.png']
}}
