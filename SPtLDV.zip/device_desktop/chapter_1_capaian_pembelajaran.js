DesktopResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#f8f7f7","bgImage":"images/background.png","bgSize":"1009px 630px","bgRepeat":"repeat-y"}
,
"image5363":{"x":84,"y":473,"w":340,"h":231,"bOffBottom":0,"i":"images/e6057850d936b3d6ebb65860e05b5553crop_image5363.png"}
,
"button5540":{"x":921,"y":587,"w":47.000000,"h":45.000000,"stylemods":[{"sel":"div.button5540Text","decl":" { position:fixed; left:2px; top:2px; width:42px; height:40px;}"},{"sel":"span.button5540Text","decl":" { display:table-cell; position:relative; width:42px; height:40px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC8AAAAtCAYAAAA+7zKnAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAeSURBVGhD7cEBAQAAAIIg/69uSEABAAAAAAAAAJwaITkAAYWmX4QAAAAASUVORK5CYII=" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC8AAAAtCAYAAAA+7zKnAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAeSURBVGhD7cEBAQAAAIIg/69uSEABAAAAAAAAAJwaITkAAYWmX4QAAAAASUVORK5CYII=" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC8AAAAtCAYAAAA+7zKnAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAeSURBVGhD7cEBAQAAAIIg/69uSEABAAAAAAAAAJwaITkAAYWmX4QAAAAASUVORK5CYII=" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC8AAAAtCAYAAAA+7zKnAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAeSURBVGhD7cEBAQAAAIIg/69uSEABAAAAAAAAAJwaITkAAYWmX4QAAAAASUVORK5CYII="  ,"fd": "images/brown_basic_next.png" ,"fdO": "images/brown_basic_next_over.png" ,"fdD": "images/brown_basic_next_click.png" ,"fdDi": "images/brown_basic_next.png" ,"p": "M 0.000000 0.000000 L 46.000000 0.000000 L 46.000000 44.000000 L 0.000000 44.000000 L 0.000000 0.000000 z","i":"images/button5540.png","irol":"images/button5540_over.png","ion":"images/button5540_down.png","idis":"images/button5540_disabled.png"}
,
"button5754":{"x":854,"y":586,"w":61.000000,"h":46.000000,"stylemods":[{"sel":"div.button5754Text","decl":" { position:fixed; left:2px; top:2px; width:56px; height:41px;}"},{"sel":"span.button5754Text","decl":" { display:table-cell; position:relative; width:56px; height:41px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAAuCAYAAACbIBHcAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAiSURBVGhD7cEBDQAAAMKg909tDjegAAAAAAAAAAAAAIAvAywGAAHQ5YwvAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAAuCAYAAACbIBHcAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAiSURBVGhD7cEBDQAAAMKg909tDjegAAAAAAAAAAAAAIAvAywGAAHQ5YwvAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAAuCAYAAACbIBHcAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAiSURBVGhD7cEBDQAAAMKg909tDjegAAAAAAAAAAAAAIAvAywGAAHQ5YwvAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD0AAAAuCAYAAACbIBHcAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAiSURBVGhD7cEBDQAAAMKg909tDjegAAAAAAAAAAAAAIAvAywGAAHQ5YwvAAAAAElFTkSuQmCC"  ,"fd": "images/brown_cutout_home.png" ,"fdO": "images/brown_cutout_home_over.png" ,"fdD": "images/brown_cutout_home_click.png" ,"fdDi": "images/brown_cutout_home.png" ,"p": "M 0.000000 0.000000 L 60.000000 0.000000 L 60.000000 45.000000 L 0.000000 45.000000 L 0.000000 0.000000 z","i":"images/button5754.png","irol":"images/button5754_over.png","ion":"images/button5754_down.png","idis":"images/button5754_disabled.png"}
,
"text4845":{"x":295,"y":53,"w":386,"h":80,"txtscale":100,"bOffBottom":0}
,
"text5126":{"x":171,"y":223,"w":693,"h":315,"txtscale":100,"bOffBottom":0}
,
"image4429":{"x":0,"y":0,"w":1009,"h":86,"bOffBottom":0,"i":"images/header.png"}
,
"image4431":{"x":0,"y":572,"w":1009,"h":90,"bOffBottom":1,"i":"images/footer.png"}
,
"image4826":{"x":292,"y":0,"w":396,"h":153,"bOffBottom":0,"i":"images/gemini_generated_image_qg4fnvqg4fnvqg4f_1_crop_image2899.png"}
,
"image5045":{"x":80,"y":144,"w":855,"h":485,"bOffBottom":0,"i":"images/31ecc4ef3973fe832c41b79a569508dccrop_image5045.png"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/header.png','images/footer.png','images/background.png','images/brown_basic_next.png','images/brown_basic_next_over.png','images/brown_basic_next_click.png','images/brown_cutout_home.png','images/brown_cutout_home_over.png','images/brown_cutout_home_click.png','images/gemini_generated_image_qg4fnvqg4fnvqg4f_1_crop_image2899.png','images/31ecc4ef3973fe832c41b79a569508dccrop_image5045.png','images/e6057850d936b3d6ebb65860e05b5553crop_image5363.png','images/button5540.png','images/button5540_over.png','images/button5540_down.png','images/button5540_disabled.png','images/button5754.png','images/button5754_over.png','images/button5754_down.png','images/button5754_disabled.png']
}}
