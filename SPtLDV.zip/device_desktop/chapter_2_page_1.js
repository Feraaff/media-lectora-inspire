DesktopResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#f8f7f7","bgImage":"images/background.png","bgSize":"1009px 630px","bgRepeat":"repeat-y"}
,
"text6893":{"x":295,"y":53,"w":386,"h":80,"txtscale":100,"bOffBottom":0}
,
"image4429":{"x":0,"y":0,"w":1009,"h":86,"bOffBottom":0,"i":"images/header.png"}
,
"image4431":{"x":0,"y":572,"w":1009,"h":90,"bOffBottom":1,"i":"images/footer.png"}
,
"image6090":{"x":292,"y":0,"w":396,"h":153,"bOffBottom":0,"i":"images/gemini_generated_image_qg4fnvqg4fnvqg4f_1_crop_image2899.png"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/header.png','images/footer.png','images/background.png','images/gemini_generated_image_qg4fnvqg4fnvqg4f_1_crop_image2899.png']
}}
