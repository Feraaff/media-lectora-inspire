DesktopResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#f8f7f7","bgImage":"images/background.png","bgSize":"1009px 630px","bgRepeat":"repeat-y"}
,
"image4429":{"x":0,"y":0,"w":1009,"h":86,"bOffBottom":0,"i":"images/header.png"}
,
"image4431":{"x":0,"y":572,"w":1009,"h":90,"bOffBottom":1,"i":"images/footer.png"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/header.png','images/footer.png','images/background.png']
}}
