PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":450,"bgColor":"#999999","bgImage":"images/background002.png","bgSize":"785px 569px","bgRepeat":"no-repeat"}
,
"image4429":{"x":0,"y":0,"w":785,"h":86,"bOffBottom":0,"i":"images/header002.png"}
,
"image4431":{"x":0,"y":374,"w":785,"h":76,"bOffBottom":1,"i":"images/footer002.png"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/header002.png','images/footer002.png','images/background002.png']
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#999999","bgImage":"images/background003.png","bgSize":"480px 733px","bgRepeat":"repeat-y"}
,
"image4429":{"x":0,"y":0,"w":480,"h":86,"bOffBottom":0,"i":"images/header003.png"}
,
"image4431":{"x":0,"y":694,"w":480,"h":69,"bOffBottom":1,"i":"images/footer003.png"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/header003.png','images/footer003.png','images/background003.png']
}}
