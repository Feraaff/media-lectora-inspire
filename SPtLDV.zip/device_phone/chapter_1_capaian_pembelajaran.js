PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":548,"bgColor":"#999999","bgImage":"images/background002.png","bgSize":"785px 569px","bgRepeat":"no-repeat"}
,
"image5363":{"x":65,"y":368,"w":265,"h":180,"bOffBottom":0,"i":"images/e6057850d936b3d6ebb65860e05b5553crop_image5363.png"}
,
"button5540":{"x":717,"y":457,"w":37.000000,"h":35.000000,"stylemods":[{"sel":"div.button5540Text","decl":" { position:fixed; left:2px; top:2px; width:32px; height:30px;}"},{"sel":"span.button5540Text","decl":" { display:table-cell; position:relative; width:32px; height:30px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACUAAAAjCAYAAAATx8MeAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cExAQAAAMKg9U9tB2+gAAAAAAAuAxRfAAGO9JC+AAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACUAAAAjCAYAAAATx8MeAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cExAQAAAMKg9U9tB2+gAAAAAAAuAxRfAAGO9JC+AAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACUAAAAjCAYAAAATx8MeAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cExAQAAAMKg9U9tB2+gAAAAAAAuAxRfAAGO9JC+AAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACUAAAAjCAYAAAATx8MeAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cExAQAAAMKg9U9tB2+gAAAAAAAuAxRfAAGO9JC+AAAAAElFTkSuQmCC"  ,"fd": "images/brown_basic_next.png" ,"fdO": "images/brown_basic_next_over.png" ,"fdD": "images/brown_basic_next_click.png" ,"fdDi": "images/brown_basic_next.png" ,"p": "M 0.000000 0.000000 L 36.000000 0.000000 L 36.000000 34.000000 L 0.000000 34.000000 L 0.000000 0.000000 z"}
,
"button5754":{"x":664,"y":456,"w":48.000000,"h":36.000000,"stylemods":[{"sel":"div.button5754Text","decl":" { position:fixed; left:2px; top:2px; width:43px; height:31px;}"},{"sel":"span.button5754Text","decl":" { display:table-cell; position:relative; width:43px; height:31px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAkCAYAAADPRbkKAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAdSURBVFhH7cEBAQAAAIIg/69uSEABAAAAAADAlwEbJAABuOYLPAAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAkCAYAAADPRbkKAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAdSURBVFhH7cEBAQAAAIIg/69uSEABAAAAAADAlwEbJAABuOYLPAAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAkCAYAAADPRbkKAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAdSURBVFhH7cEBAQAAAIIg/69uSEABAAAAAADAlwEbJAABuOYLPAAAAABJRU5ErkJggg==" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAkCAYAAADPRbkKAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAdSURBVFhH7cEBAQAAAIIg/69uSEABAAAAAADAlwEbJAABuOYLPAAAAABJRU5ErkJggg=="  ,"fd": "images/brown_cutout_home.png" ,"fdO": "images/brown_cutout_home_over.png" ,"fdD": "images/brown_cutout_home_click.png" ,"fdDi": "images/brown_cutout_home.png" ,"p": "M 0.000000 0.000000 L 47.000000 0.000000 L 47.000000 35.000000 L 0.000000 35.000000 L 0.000000 0.000000 z"}
,
"text4845":{"x":28,"y":60,"w":727,"h":76,"txtscale":100,"bOffBottom":0}
,
"text5126":{"x":28,"y":60,"w":727,"h":204,"txtscale":100,"bOffBottom":0}
,
"image4429":{"x":0,"y":0,"w":785,"h":86,"bOffBottom":0,"i":"images/header002.png"}
,
"image4431":{"x":0,"y":472,"w":785,"h":76,"bOffBottom":1,"i":"images/footer002.png"}
,
"image4826":{"x":227,"y":0,"w":308,"h":119,"bOffBottom":0,"i":"images/gemini_generated_image_qg4fnvqg4fnvqg4f_1_crop_image2899.png"}
,
"image5045":{"x":62,"y":112,"w":665,"h":377,"bOffBottom":0,"i":"images/31ecc4ef3973fe832c41b79a569508dccrop_image5045.png"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/header002.png','images/footer002.png','images/background002.png','images/gemini_generated_image_qg4fnvqg4fnvqg4f_1_crop_image2899.png','images/31ecc4ef3973fe832c41b79a569508dccrop_image5045.png','images/e6057850d936b3d6ebb65860e05b5553crop_image5363.png']
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#999999","bgImage":"images/background003.png","bgSize":"480px 733px","bgRepeat":"repeat-y"}
,
"image5363":{"x":40,"y":473,"w":162,"h":110,"bOffBottom":0,"i":"images/e6057850d936b3d6ebb65860e05b5553crop_image5363.png"}
,
"button5540":{"x":438,"y":587,"w":23.000000,"h":22.000000,"stylemods":[{"sel":"div.button5540Text","decl":" { position:fixed; left:2px; top:2px; width:18px; height:17px;}"},{"sel":"span.button5540Text","decl":" { display:table-cell; position:relative; width:18px; height:17px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAAWCAYAAAArdgcFAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAXSURBVEhLY2AYBaNgFIyCUTAKRsHIAgAH/gABb1qXsAAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAAWCAYAAAArdgcFAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAXSURBVEhLY2AYBaNgFIyCUTAKRsHIAgAH/gABb1qXsAAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAAWCAYAAAArdgcFAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAXSURBVEhLY2AYBaNgFIyCUTAKRsHIAgAH/gABb1qXsAAAAABJRU5ErkJggg==" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAAWCAYAAAArdgcFAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAXSURBVEhLY2AYBaNgFIyCUTAKRsHIAgAH/gABb1qXsAAAAABJRU5ErkJggg=="  ,"fd": "images/brown_basic_next.png" ,"fdO": "images/brown_basic_next_over.png" ,"fdD": "images/brown_basic_next_click.png" ,"fdDi": "images/brown_basic_next.png" ,"p": "M 0.000000 0.000000 L 22.000000 0.000000 L 22.000000 21.000000 L 0.000000 21.000000 L 0.000000 0.000000 z"}
,
"button5754":{"x":406,"y":586,"w":30.000000,"h":22.000000,"stylemods":[{"sel":"div.button5754Text","decl":" { position:fixed; left:2px; top:2px; width:25px; height:17px;}"},{"sel":"span.button5754Text","decl":" { display:table-cell; position:relative; width:25px; height:17px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAWCAYAAADXYyzPAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCU+gAADgbQpmAAFq+0vSAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAWCAYAAADXYyzPAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCU+gAADgbQpmAAFq+0vSAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAWCAYAAADXYyzPAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCU+gAADgbQpmAAFq+0vSAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAWCAYAAADXYyzPAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCU+gAADgbQpmAAFq+0vSAAAAAElFTkSuQmCC"  ,"fd": "images/brown_cutout_home.png" ,"fdO": "images/brown_cutout_home_over.png" ,"fdD": "images/brown_cutout_home_click.png" ,"fdDi": "images/brown_cutout_home.png" ,"p": "M 0.000000 0.000000 L 29.000000 0.000000 L 29.000000 21.000000 L 0.000000 21.000000 L 0.000000 0.000000 z"}
,
"text4845":{"x":28,"y":60,"w":426,"h":76,"txtscale":100,"bOffBottom":0}
,
"text5126":{"x":28,"y":60,"w":426,"h":374,"txtscale":100,"bOffBottom":0}
,
"image4429":{"x":0,"y":0,"w":480,"h":86,"bOffBottom":0,"i":"images/header003.png"}
,
"image4431":{"x":0,"y":694,"w":480,"h":69,"bOffBottom":1,"i":"images/footer003.png"}
,
"image4826":{"x":139,"y":0,"w":188,"h":73,"bOffBottom":0,"i":"images/gemini_generated_image_qg4fnvqg4fnvqg4f_1_crop_image2899.png"}
,
"image5045":{"x":38,"y":144,"w":407,"h":231,"bOffBottom":0,"i":"images/31ecc4ef3973fe832c41b79a569508dccrop_image5045.png"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/header003.png','images/footer003.png','images/background003.png','images/gemini_generated_image_qg4fnvqg4fnvqg4f_1_crop_image2899.png','images/31ecc4ef3973fe832c41b79a569508dccrop_image5045.png','images/e6057850d936b3d6ebb65860e05b5553crop_image5363.png']
}}
